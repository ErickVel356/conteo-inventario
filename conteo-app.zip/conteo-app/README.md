# Conteo Físico de Inventario

## Deploy en Render.com (3 pasos)

1. Sube esta carpeta a GitHub:
   - Ve a github.com → New repository → "conteo-inventario" → Create
   - Sube todos los archivos

2. Ve a render.com → New → Web Service → conecta tu repo de GitHub

3. Render detecta automáticamente la configuración. Dale Deploy.

En ~3 minutos tienes tu URL lista (ej: https://conteo-inventario.onrender.com)
